Vue.use(vuelidate.default)

const ageRange = validators.between(12, 120)

const app = new Vue({
    el:'#app',
    data: {
        form:{
        name: null,
        age: null,
        email: null
        }
    },
    validations:{
        form: {
            name: {
                required: validators.required,
                minLength: validators.minLength(3)
            },
            age: {
                required: validators.required,
                integer: validators.integer,
                ageRange
            },
            email: {
                email: validators.email,
                required: validators.required
            },
        }
    },

    methods:{
        shouldAppendValidClass (field) {
            return !field.$invalid && field.$model && field.$dirty
        },

        shouldAppendErrorClass (field) {
            return field.$error
        },
        submitForm (e) {
            if (!this.$v.form.$invalid) {
                console.log('Form Submitted', this.form)
            } else {
                console.log('Invalid form')
            }
        },

    },
})
